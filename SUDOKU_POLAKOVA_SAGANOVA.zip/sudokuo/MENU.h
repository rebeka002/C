#pragma once
//#define N 9

int display();//obsahuje NEW GAME a LOAD STARTED GAME volitelne uzivatelom
void menu(); //nacitanie hry a hracej plochy
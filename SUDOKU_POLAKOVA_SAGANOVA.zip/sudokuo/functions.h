#pragma once
#define N 9

int input_function(int game_board[N][N]); //funkce pomocou ktorej uzivatel zadava suradnice prvku matice ku ktoremu chce pristupovat + vyhodnocovanie
void print_gameboard(int game_board[N][N]); //print aktualneho game boardu 
void generate_valid_positions(int game_board[N][N]); //kontrola ci dane miesto je prepisovatelne
void save_game_board(int game_board[N][N]); //ukladanie rozohrateho game boardu
int check_victory(int game_board[N][N]);
int check_column(int game_board[N][N]); //kontrola stlpcov
int check_row(int game_board[N][N]);  //kontrola riadkov
int check_box(int game_board[N][N]); //kontrola 3x3 boxu
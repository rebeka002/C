﻿// sudoku_ours.cpp : Defines the entry point for the application.
//
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "sudoku_ours.h"
#include "MENU.h"
#include"functions.h"
#include<vector>
#include <utility>





#define N 9

using namespace std;


int main()
{
       
	display();
	menu();
	return 0;
};
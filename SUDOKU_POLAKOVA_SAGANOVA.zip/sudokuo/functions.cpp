// trying.cpp : Defines the entry point for the application.

#include "functions.h"
#include <iostream>
#include <stdlib.h>
#include <ctype.h>
#include <vector>
#include <stdio.h>
#include "MENU.h"
#include <fstream>
#define N 9
#define ANSI_COLOR_CYAN "\x1b[36m"
#define RED "\x1b[31m"
#define B "\x1b[0m"



using namespace std;
//GLOBAL VARIABLES
vector <pair<int, int>> vec; //VECTOR OF PAIRS
int x, y, n, valid, victory = 0;


void save_game_board(int game_board[N][N])
{
	//SAVE MATRIX 
	FILE* outputFile;
	
	fopen_s(&outputFile, "C:\\sudokuo\\out\\build\\x64-Debug\\saved_matrix.txt","w+");
	
	for (int m = 0; m < N; m++)
	{
		for (int n = 0; n < N; n++)
		{
			fprintf(outputFile, "%d ", game_board[m][n]);
		};
		fprintf(outputFile, "\n");
	};
	fclose(outputFile);

};

int check_victory(int game_board[N][N]) {

	for (int num = 0; num < 81; num++) {
		//check row
		int arr_r[N] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		for (int p = 0; p < N; p++) {
			arr_r[p] = game_board[num][p];
			if (n == arr_r[p]) {
				victory = 0;
				break;
			}
			else { victory = 1; }
		}
		//check column
		int arr_c[N] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		for (int x = 0; x < N; x++) {
			arr_c[x] = game_board[x][num];
			if (n == arr_c[x]) {
				victory = 0;
				break;
			}
			else { victory = 1; }
		};
		//check box
		int r, c;

		int start_row = (x - 1) - (x - 1) % 3;
		int	start_col = (y - 1) - (y - 1) % 3;

		vector< int > array;

		for (r = start_row; r < start_row + 3; r++) {
			for (c = start_col; c < start_col + 3; c++) {
				array.push_back(game_board[r][c]);
			};
		};
		for (int o = 0; o < N; o++) {
			if (n == array[o]) {
				victory = 0;
				break;
			}
			else { victory = 1;}
		}
	};

	return victory; 
	return 0;
};

void generate_valid_positions(int game_board[N][N]) {

	for (int m = 0; m < N; m++) {
		for (int n = 0; n < N; n++) {
			if (game_board[m][n] == 0) {
				vec.push_back(make_pair(m, n));

			};
		};
	};
};

int check_row(int game_board[N][N]) {
	int arr_r[N] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	for (int p = 0; p < N; p++) {
		arr_r[p] = game_board[x - 1][p];
		if (n == arr_r[p]) {
			valid += 2;
			break;
		};
	};
	return valid;
	return 0;
};

int check_column( int game_board[N][N]) {

	int arr_c[N] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	for (int x = 0; x < N; x++) {
		arr_c[x] = game_board[x][y - 1];

		if (n == arr_c[x]) {
			valid += 1;
			break;
		};
	};
	return valid;
	return 0;
}

int check_box( int game_board[N][N]) {
	int r, c;

	int start_row = (x - 1) - (x - 1) % 3;
	int	start_col = (y - 1) - (y - 1) % 3;

	vector< int > array;

	for (r = start_row; r < start_row + 3; r++) {
		for (c = start_col; c < start_col + 3; c++) {
			array.push_back(game_board[r][c]);

		};
	};
	for (int o = 0; o < N; o++) {
		if (n == array[o])
			valid = 4;
	};
	return valid; 
	return 0; 
};

int input_function(int game_board[N][N]) {

	generate_valid_positions(game_board);
	
	while(victory ==0){

		int err = 0;
	
		printf( B "type row and column you want to rewrite (starting from up) "); //zadanie suradnice ktoru ideme prepisat
		scanf_s("%d %d", &x, &y);

		printf("type number you want to input   "); // zadanie cisla, ktore vkladame 
		scanf_s("%d", &n);

		check_row(game_board);
		check_column(game_board);
		check_box(game_board);
	
		//CHECK IF POSITION IS VALID

			for (int i = 0; i < vec.size(); i++) {

				if (vec[i].first == x-1 && vec[i].second == y-1) {
					err = 1;
					break ;
				}
				else { err = 0; }
			};

			// CHECK AND PRINT OF USERS INPUT ERRORS

			
			
			if (x > N + 1 || y > N + 1) {
				printf(RED "\n\nOOOOPS! NUMBERS OF POSITIONS MUST BE FROM 1 TO 9!\n\n");
				
				input_function(game_board);
			};
			
			if (n < N + 1 && err == 1) {
				game_board[x - 1][y - 1] =  n;

				print_gameboard(game_board);
			}
			else if (n > N + 1) {
				printf(RED "\n\nOOOOPS! YOU CAN ONLY INPUT NUMBERS FROM 1 TO 9!\n\n");
			
				input_function(game_board);

			}
			else if (err == 0) {
				printf(RED "\n\nOOOOPS! YOU CAN NOT INPUT NUMBER HERE!\n\n");
			
				print_gameboard(game_board);
				input_function(game_board);

			};
			//CHECK AND PRINT OF USERS INPUT ERRORS
			switch (valid) {
			case 1: {
				printf("\n\nOOOPS! THE NUMBER ALREADY IS IN THE COLUMN!\n \n");
				valid = 0;
				break;
			}

			case 2: {
				printf("\n\nOOOPS! THE NUMBER ALREADY IS IN THE ROW!\n \n");
				valid = 0;
				break;
			}
			case 3: {
				printf("\n\nOOOPS! THE NUMBER ALREADY IS IN THE ROW AND COLUMN!\n \n");
				valid = 0;
				break;
			}

			case 4: {
				printf("\n\nOOOPS! THE NUMBER ALREADY IS IN THE 3x3 BOX!\n \n");
				valid = 0;
				break;
			}  
			};

			save_game_board(game_board);
			
			

			
	};

	return 0;
};


void print_gameboard(int game_board[N][N]) {
	printf(ANSI_COLOR_CYAN "\n_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n\n");

	for (int y = 0; y < N; y++) {
		for (int x = 0; x < N; x++)
		{
			printf(B " %d ", game_board[y][x]);
			if ((x + 1) % 3 == 0) {
				printf(ANSI_COLOR_CYAN "|");
			}
		};
		printf("\n");
		if ((y + 1) % 3 == 0) {
			printf(ANSI_COLOR_CYAN "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n\n");
		};
	};
};
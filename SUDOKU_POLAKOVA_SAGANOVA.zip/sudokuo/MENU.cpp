#include"MENU.h"
#include<iostream>
#include <fstream>
#include<windows.h>
#include<stdlib.h>
#include <stdio.h>
#include <set>
#include <conio.h>
#include <ctype.h>
#include "functions.h"

#define N 9
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define B "\x1b[0m"
using namespace std; 



//GLOBAL VARIABLES
int chosen_matrix;
int game_board[N][N];

int display()
{
	system("CLS");
	printf(ANSI_COLOR_CYAN  "\n\t\t\t\t\tSUDOKU\n\n\n");
	printf(B "\t\t\t\t\Welcome to our sudoku game!\n \n\tThis game is played using keyboard.\n");
	printf("\n\tThe program will ask you to input the position you'd like to rewrite.\n\tPlease, enter two numbers of position with space.\n\n\tGood luck!\n");
	printf("\n\n\t\tNEW GAME (press 1 and enter for new game)\n");
	printf("\n\t\n\t\tLOAD STARTED GAME (press 2 and enter for loading started game)  ");
	scanf_s("%d", &chosen_matrix);
	printf("\n\n");

	return chosen_matrix;

	return 0;
};

void menu(){
	int game_board[N][N];

	if (chosen_matrix == 2) {//prekopiruje sa vybrata (rozohrana) matica do game_board
		FILE* outputFile;
		int num;
		fopen_s(&outputFile, "C:\\sudokuo\\out\\build\\x64-Debug\\saved_matrix.txt", "r");
		for (int k = 0; k < 100; k++) {
			if (feof(outputFile)) {
				break;
			};
			for (int x = 0; x < N; x++) {
				for (int y = 0; y < N; y++) {
					fscanf_s(outputFile, "%d", &game_board[x][y]);
				};
			}
		}
		fclose(outputFile);
	}
	
	else if (chosen_matrix == 1) {//prekopiruje sa vybrata (nova) matica do game_board
		FILE* outputFile;
		int num;
		fopen_s(&outputFile, "C:\\sudokuo\\out\\build\\x64-Debug\\new_matrix.txt", "r");
		for (int k = 0; k < 100; k++) {
			if (feof(outputFile)) {
				break;
			};
			for (int x = 0; x < N; x++) {
				for (int y = 0; y < N; y++) {
					fscanf_s(outputFile, "%d", &game_board[x][y]);
				};
			}
		}
		fclose(outputFile);
	}
	else /*if (chosen_matrix != 1 && chosen_matrix != 2)*/ {
		char klavesa;
		printf("\n\tChoose from 1 or 2 please! \n\n");
		printf("to continue press [c] + Enter: ");
		for (;;) {
			scanf_s("%c", &klavesa);
			if (klavesa == 99) {
				display();
				menu();
			};
		};
	};

	print_gameboard(game_board);

	save_game_board(game_board);

	input_function(game_board);
};